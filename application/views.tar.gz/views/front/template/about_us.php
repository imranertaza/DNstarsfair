<div class="main_content">
	<div class="news_feed">
    	<h2 class="gradiant">News Feed</h2>
    	<ul>
    		<li>Oct 23, 2014Nestlé ranked No. 9 most attractive employer in world by LinkedIn</li>
            <li>Oct 23, 2014Nestlé ranked No. 9 most attractive employer in world by LinkedIn</li>
            <li>Oct 23, 2014Nestlé ranked No. 9 most attractive employer in world by LinkedIn</li>
        </ul>
    </div>
    <div class="society">
    	<h2 class="gradiant">Loihein co society</h2>
    	<img src="<?php echo base_url(); ?>assets/front/images/re_3.jpg" alt="social" />
        <p>Beyond meeting our commitments on environmental sustainability and compliance we aim to create shared value for society and shareholders.</p>
    </div>
    <div class="pro_list">
    	<h2 class="gradiant">Product's list</h2>
    	<div class="pro_li">
        	<img src="<?php echo base_url(); ?>assets/front/images/pro_1.jpg" alt="product list" />
            <p>We have great water product.</p>
            <br class="clear" />
        </div>
        <div class="pro_li">
        	<img src="<?php echo base_url(); ?>assets/front/images/pro_2.jpg" alt="product list" />
            <p>We have great water product.</p>
            <br class="clear" />
        </div>
        <div class="pro_li">
        	<img src="<?php echo base_url(); ?>assets/front/images/pro_3.jpg" alt="product list" />
            <p>We have great water product.</p>
            <br class="clear" />
        </div>
    </div>
    
    <div class="social_ask">
        <div class="follow_us">
            <h2 class="gradiant">Follow us</h2>
            <div class="chatarea">Join the convertion and stay update and news and events</div>
            <div class="social_icon">
                <img src="<?php echo base_url(); ?>assets/front/images/so_f.jpg" alt="Facebook" />
                <img src="<?php echo base_url(); ?>assets/front/images/so_r.jpg" alt="Facebook" />
                <img src="<?php echo base_url(); ?>assets/front/images/so_t.jpg" alt="Facebook" />
                <img src="<?php echo base_url(); ?>assets/front/images/so_y.jpg" alt="Facebook" />
            </div>
        </div>
        <div class="ask_me gradiant"><span class="red">?</span>  ask LOIHEIN</div>
    </div>
    <br class="clear" />
</div>
<div class="content_section gradiant">
	<div class="gallery_sec">
    	<div class="powerful">WE BUILD POWERFUL<br /><span class="white">BRANDS</span></div>
        <div class="gallery">
        	<div class="variable-width">
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_4.jpg" /></div>
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_5.jpg" /></div>
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_4.jpg" /></div>
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_5.jpg" /></div>
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_4.jpg" /></div>
              <div class="each_image"><img src="<?php echo base_url(); ?>assets/front/images/pro_5.jpg" /></div>
            </div>
        </div>
        <div class="try_brand">YOU CAN TRY OUR <br /><span class="white">BRANDS</span></div>
        <br class="clear" />
    </div>
</div>
<div class="quick_links">
	<div class="about_us footer_top_common">
    	<h2 class="top_footer_title">About Us</h2>
        <ul>
        	<li><a href="#">Chairman's Message</a></li>
            <li><a href="#">History</a></li>
            <li><a href="#">Philosophy</a></li>
        </ul>
    </div>
    <div class="product footer_top_common">
    	<h2 class="top_footer_title">Products</h2>
        <ul>
        	<li><a href="#">Purified Drinking Water</a></li>
            <li><a href="#">Carbonated Soft Drinks</a></li>
            <li><a href="#">Energy Drinks</a></li>
        </ul>
    </div>
    <div class="distribution footer_top_common">
    	<h2 class="top_footer_title">Distribution</h2>
        <p>Loi Hein Distribution Company (LHDC) is managed as an independent business unit part of the Loi Hein Group of Companies. </p>
    </div>
    <br class="clear" />
</div>