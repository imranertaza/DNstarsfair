    </div>
 </div>

<div class="footer">
<div class="container">  
    <div class="row">
        <div class="col-md-12">
        <div class="row">
        <div class="col-md-3">
            <div class="costomer_support"><?php print $footer_widget_title; ?></div><!--end of costomer_support-->
            <div class="costomer_support_ditals"><?php print $footer_widget_description; ?></div><!--end of costomer_support_ditals-->
        </div><!--end of footer_left-->
        <div class="col-md-3">
            <!--<div class="footer_menu_write">Quick Menu</div-->><!--end of footer_menu_write-->
            <div class="footer_menu">
               
            </div><!--end of footer_menu_write-->
        </div><!--end of footer_midil-->
        <div class="col-md-3">
            <div class="footer_right_icone_write">Follow Us</div><!--end of footer_right_icone_write-->
            <div class="footer_right_icone"><a href="#"><i class="fa fa-facebook-square sosal"></i></a></div><!--end of footer_right_icone-->
            <div class="footer_right_icone"><a href="#"><i class="fa fa-twitter-square sosal"></i></a></div><!--end of footer_right_icone-->
            <div class="footer_right_icone"><a href="#"><i class="fa fa-linkedin-square sosal"></i></a></div><!--end of footer_right_icone-->
            <div class="footer_right_icone"><a href="#"><i class="fa fa-google-plus-square sosal"></i></a></div><!--end of footer_right_icone-->
        </div><!--end of footer_menu_write-->
        <div class="col-md-3">
            <div class="costomer_support"><?php print $footer_widget2_title; ?></div><!--end of costomer_support-->
            <div class="costomer_support_ditals"><?php print $footer_widget2_description; ?></div><!--end of costomer_support_ditals-->
        </div><!--end of footer_left-->
        </div>
        </div>
    </div>
    
</div>
</div>

<div class="short_footer short_footerl">
	<div class="container">  
    <div class="row">
    <div class="col-md-12 short_footer_write">Copyright © 2019 Uturn  | All rights reserved | </div><!--end of short_footer_write-->
    </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/slick/slick.js"></script>

<script type="application/javascript">
$('.variable-width').slick({
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 1,
  centerMode: true,
  variableWidth: true
});
</script>
 
</body>
</html>
