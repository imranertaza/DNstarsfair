<div class="content_top">
    <div class="sarch_bar">
        <div class="select_categoris">All Categories</div>
        <div class="saech_box"></div>
        <div class="sarch">Search</div>
    </div>
    <div class="hotline">Hotline : +88 0174070770<br />9 AM to 8 PM (Everyday)</div>
    <br clear="all" />
</div>