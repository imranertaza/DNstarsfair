 <div class="contentl">
  <div class="content">
        <!--<div class="product_top">Special Offer <a href="#">View all >></a></div>-->
        
        <?php print $this->pro_functions->show_products_by_catID($cat_id); ?>
        
  </div><!--end of content-->
  <br clear="all" />
 </div><!--end of contentl-->
 <!--finish of the content-->
 
 
 <div class="product_listl">
     	<div class="product_list">
        	<div class="product_list_write">Brands</div><!--end of product_list_write-->
            <div class="gallery product_list_white">
                <div class="variable-width">
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                <div class="each_image product_list_white_img"><img src="<?php echo base_url(); ?>assets/images/pc.png" /></div>
                </div>
            </div>
          	</div>
     </div>
