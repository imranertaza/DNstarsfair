<div class="order_by_phone">
        	<div class="order_text">Order By<br />Phone<br /><br /><br />Call now</div>
            
            <div class="phone"><img src="<?php echo base_url(); ?>assets/images/phone.png" /></div>
            <div class="call">+88 0174070770</div>
            <br clear="all" />
        </div>