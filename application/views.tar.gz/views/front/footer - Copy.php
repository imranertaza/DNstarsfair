<!--start of the footer-->
  	<div class="footerl">
    	<div class="footer">
        	<div class="footer_left">
            	<div class="costomer_support">About Us</div><!--end of costomer_support-->
                <div class="costomer_support_ditals">Beciegast nveritekytars lertyasuayse asety kertysnemo eniptaiadesBeciegast nveritekytars 		                 lertyasuayse asety kertya fae kertyuderas lertyasuayse lertyasuayse snemo eniptaiades</div><!--end of costomer_support_ditals-->
            </div><!--end of footer_left-->
            <div class="footer_midil">
            	<div class="footer_menu_write">Menu</div><!--end of footer_menu_write-->
                <div class="footer_menu">
                	<ul>
                    	<li><a href="<?php print base_url(); ?>">Home</a></li>
                        <li><a href="<?php print base_url(); ?>details/page/14.html">Other Products</a></li>
                        <li><a href="<?php print base_url(); ?>details/page/14.html">Other Services</a></li>
                        <li><a href="<?php print base_url(); ?>details/page/14.html">About Us</a></li>
                        <li><a href="<?php print base_url(); ?>details/page/14.html">Conatct Us</a></li>
                    </ul>
                </div><!--end of footer_menu_write-->
            </div><!--end of footer_midil-->
            <div class="footer_right">
            	<div class="footer_right_icone_write">Follow Us</div><!--end of footer_right_icone_write-->
                <div class="footer_right_icone"><a href="#"><img src="<?php echo base_url(); ?>assets/images/facebook.png" /></a></div><!--end of footer_right_icone-->
                <div class="footer_right_icone"><a href="#"><img src="<?php echo base_url(); ?>assets/images/twter.png" /></a></div><!--end of footer_right_icone-->
                <div class="footer_right_icone"><a href="#"><img src="<?php echo base_url(); ?>assets/images/in.png" /></a></div><!--end of footer_right_icone-->
                <div class="footer_right_icone"><a href="#"><img src="<?php echo base_url(); ?>assets/images/g+.png" /></a></div><!--end of footer_right_icone-->
            </div><!--end of footer_menu_write-->
            <div class="footer_left">
            	<div class="costomer_support">Contact Us</div><!--end of costomer_support-->
                <div class="costomer_support_ditals">Some description of Taj Jahan Computer will be here.</div><!--end of costomer_support_ditals-->
            </div><!--end of footer_left-->
            <br clear="all" />
        </div><!--end of footer-->
    </div><!--end of footerl-->
    <div class="short_footerl">
    	<div class="short_footer">
        	<div class="short_footer_write">Copyright © 2015 Mohila College | All rights reserved | Developed by <a href="//dnationsoft.com">D-NationSoft</a></div><!--end of short_footer_write-->
        </div><!--end of short_footer-->
    </div><!--end of short_footerl-->
  <!--finish of the footer--> 

 </div><!--end of mainbody-->
 
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/js/jquery-migrate-1.2.1.js"></script>
<script type="text/javascript" src="<?php echo base_url(); ?>assets/front/slick/slick.js"></script>

<script type="application/javascript">
$('.variable-width').slick({
  dots: false,
  infinite: true,
  speed: 300,
  slidesToShow: 1,
  centerMode: true,
  variableWidth: true
});
</script>
 
</body>
</html>