<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Delivery Reports</h1>
      <hr />
      <table class="table-bordered table-hover table">
        <tbody>
          <tr>
            <td>#</td>
            <td>Amount</td>
            <td>Charge</td>
            <td>Payable</td>
            <td>Rquest Time</td>
            <td>Status</td>
          </tr>
          <tr>
            <td>1</td>
            <td>464.00</td>
            <td>58.00</td>
            <td>406.00</td>
            <td>17-11-2016 21:57</td>
            <td>Confirmed</td>
          </tr>
          <tr>
            <td>2</td>
            <td>310.00</td>
            <td>38.75</td>
            <td>271.25</td>
            <td>05-10-2016 18:56</td>
            <td>Confirmed</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
