<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Withdraw Report</h1>
      <hr />
      <table class="table-bordered table-hover table">
        <tbody>
          <tr>
            <td>#</td>
            <td>Amount</td>
            <td>Charge</td>
            <td>Payable</td>
            <td>Rquest Time</td>
            <td>Status</td>
          </tr>
          <tr>
            <td>1</td>
            <td>2692.00</td>
            <td>336.50</td>
            <td>2355.50</td>
            <td>17-11-2016 22:06</td>
            <td>Confirmed</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
