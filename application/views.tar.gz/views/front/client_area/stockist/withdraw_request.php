<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Agent Withdraw Requests</h1>
      <hr />
      <div id="tabs">
        <ul class="ap_tabs">
          <li><a href="http://aponjonint.com/dashboard/withdraw_from_user" class="tabulous_active">Pending</a></li>
          <li><a href="http://aponjonint.com/dashboard/withdraw_from_user/paid">Paid</a></li>
        </ul>
        <div class="tabs_container"> No request found! </div>
      </div>
    </div>
  </div>
</div>
