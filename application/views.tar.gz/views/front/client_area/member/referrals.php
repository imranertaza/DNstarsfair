<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>User Referrals</h1>
      <hr />
      
      <div class="top_right_content">
        <table class="table-bordered table-hover table">
          <tbody>
            <tr>
              <th>Name</th>
              <th>Email</th>
              <th>Joining Date</th>
              <th>Earned</th>
            </tr>
             <?php
			foreach ($query->result() as $ref_info){
			 ?>
            <tr>
              <td><?php echo get_username_by_id($ref_info->u_id);?></td>
              <td><?php echo get_email_by_id($ref_info->u_id);?></td>
              <td><?php echo get_field_by_id_from_table("users", "time", "ID", $ref_info->u_id);?></td>
              <td>---</td>
            </tr>
             <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div>
