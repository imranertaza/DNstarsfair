<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>My Profile</h1>
      <hr />
          <table class="table-bordered table-hover table">
          
            <tbody>
             
              <tr>
                <td>Name</td>
                <td><?php echo $row->username;?></td>
              </tr>
              <tr>
                <td>Email</td>
                <td><?php echo $row->email;?></td>
              </tr>
              <tr>
                <td>Mobile</td>
                <td><?php echo $row->phn_no;?></td>
              </tr>
              <tr>
                <td>National ID</td>
                <td><?php echo $row->nid;?></td>
              </tr>
              <tr>
                <td>Father Name</td>
                <td><?php echo $row->father;?></td>
              </tr>
              <tr>
                <td>Mother Name</td>
                <td><?php echo $row->mother;?></td>
              </tr>
              <tr>
                <td>Address1</td>
                <td><?php echo $row->address1;?></td>
              </tr>
              <tr>
                <td>Address2</td>
                <td><?php echo $row->address2;?></td>
              </tr>
              <tr>
                <td>Religion</td>
                <td><?php echo get_globle($row->religion, 'religion');?></td>
              </tr>
              <tr>
                <td>Bank Name</td>
                <td><?php echo get_bank_name_by_id($row->bank_name);?></td>
              </tr>
              <tr>
                <td>Nominee</td>
                <td><?php echo $row->nominee;?></td>
              </tr>
            </tbody>
          </table>
    </div>
  </div>
</div>
