<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Member Withdraw Report</h1>
      <hr />
      <table class="table-bordered table-hover table">
        <tbody>
          <tr class="strong">
            <td>#</td>
            <td>Agent</td>
            <td>Commission</td>
            <td>Amount</td>
            <td>Charge</td>
            <td>Payable</td>
            <td>Request Time</td>
            <td>Status</td>
          </tr>
          <tr>
            <td>1</td>
            <td><?php echo $with_match->form;?></td>
            <td>Referral</td>
            <td>101.60</td>
            <td>12.70</td>
            <td>88.90</td>
            <td>03-01-2017 17:46</td>
            <td>Confirmed</td>
          </tr>
          <tr>
            <td>2</td>
            <td>upsfb-a</td>
            <td>Referral</td>
            <td>80.00</td>
            <td>10.00</td>
            <td>70.00</td>
            <td>18-10-2016 20:05</td>
            <td>Confirmed</td>
          </tr>
          <tr class="strong">
            <td colspan="3">Total</td>
            <td>181.60</td>
            <td>22.70</td>
            <td>158.90</td>
            <td colspan="2"></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
