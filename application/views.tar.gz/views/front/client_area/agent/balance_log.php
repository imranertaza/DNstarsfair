<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Balance Log</h1>
      <hr />
      <table class="table-bordered table-hover table">
        <tbody>
          <tr>
            <th>#</th>
            <th>Action</th>
            <th>Change Amount</th>
            <th>Last Balance</th>
            <th>Remarks</th>
            <th>Change By</th>
            <th>Change Time</th>
          </tr>
          <tr>
            <td>1</td>
            <td>Users Withdraw</td>
            <td>50.75</td>
            <td>209.11</td>
            <td></td>
            <td>Me</td>
            <td>20-02-2017 05:19 PM</td>
          </tr>
          <tr>
            <td>2</td>
            <td>Users Withdraw</td>
            <td>27.12</td>
            <td>158.36</td>
            <td></td>
            <td>Me</td>
            <td>05-02-2017 05:46 PM</td>
          </tr>
          <tr>
            <td>3</td>
            <td>Users Withdraw</td>
            <td>51.62</td>
            <td>131.24</td>
            <td></td>
            <td>Me</td>
            <td>05-02-2017 05:43 PM</td>
          </tr>
          <tr>
            <td>4</td>
            <td>Users Withdraw</td>
            <td>21.88</td>
            <td>79.62</td>
            <td></td>
            <td>Me</td>
            <td>24-01-2017 12:34 PM</td>
          </tr>
          <tr>
            <td>5</td>
            <td>Users Withdraw</td>
            <td>9.62</td>
            <td>57.74</td>
            <td></td>
            <td>Me</td>
            <td>24-01-2017 12:34 PM</td>
          </tr>
          <tr>
            <td>6</td>
            <td>Users Withdraw</td>
            <td>11.38</td>
            <td>48.12</td>
            <td></td>
            <td>Me</td>
            <td>19-01-2017 03:05 PM</td>
          </tr>
          <tr>
            <td>7</td>
            <td>Users Withdraw</td>
            <td>8.31</td>
            <td>36.74</td>
            <td></td>
            <td>Me</td>
            <td>13-01-2017 04:39 PM</td>
          </tr>
          <tr>
            <td>8</td>
            <td>Users Withdraw</td>
            <td>1.40</td>
            <td>28.43</td>
            <td></td>
            <td>Me</td>
            <td>10-01-2017 03:10 PM</td>
          </tr>
          <tr>
            <td>9</td>
            <td>Product Sale</td>
            <td>95.00</td>
            <td>27.03</td>
            <td></td>
            <td>Me</td>
            <td>10-01-2017 02:48 PM</td>
          </tr>
          <tr>
            <td>10</td>
            <td>Users Product Balance</td>
            <td>26.60</td>
            <td>767.03</td>
            <td></td>
            <td>Unknown</td>
            <td>10-01-2017 02:35 PM</td>
          </tr>
          <tr>
            <td>11</td>
            <td>Product Sale</td>
            <td>645.00</td>
            <td>122.03</td>
            <td></td>
            <td>Me</td>
            <td>10-01-2017 02:35 PM</td>
          </tr>
          <tr>
            <td>12</td>
            <td>Users Withdraw</td>
            <td>41.12</td>
            <td>740.43</td>
            <td></td>
            <td>Me</td>
            <td>10-01-2017 02:20 PM</td>
          </tr>
          <tr>
            <td>13</td>
            <td>Users Withdraw</td>
            <td>16.62</td>
            <td>699.31</td>
            <td></td>
            <td>Me</td>
            <td>09-01-2017 08:43 PM</td>
          </tr>
          <tr>
            <td>14</td>
            <td>Users Withdraw</td>
            <td>17.06</td>
            <td>682.69</td>
            <td></td>
            <td>Me</td>
            <td>07-01-2017 04:36 PM</td>
          </tr>
          <tr>
            <td>15</td>
            <td>Users Withdraw</td>
            <td>26.25</td>
            <td>665.63</td>
            <td></td>
            <td>Me</td>
            <td>27-12-2016 11:45 AM</td>
          </tr>
          <tr>
            <td>16</td>
            <td>Users Withdraw</td>
            <td>31.00</td>
            <td>639.38</td>
            <td></td>
            <td>Me</td>
            <td>26-12-2016 03:15 PM</td>
          </tr>
          <tr>
            <td>17</td>
            <td>Users Withdraw</td>
            <td>94.50</td>
            <td>608.38</td>
            <td></td>
            <td>Me</td>
            <td>17-12-2016 12:32 PM</td>
          </tr>
          <tr>
            <td>18</td>
            <td>Users Withdraw</td>
            <td>161.00</td>
            <td>513.88</td>
            <td></td>
            <td>Me</td>
            <td>14-12-2016 02:36 PM</td>
          </tr>
          <tr>
            <td>19</td>
            <td>Users Withdraw</td>
            <td>11.29</td>
            <td>352.88</td>
            <td></td>
            <td>Me</td>
            <td>13-12-2016 06:36 PM</td>
          </tr>
          <tr>
            <td>20</td>
            <td>Users Product Balance</td>
            <td>57.00</td>
            <td>398.59</td>
            <td></td>
            <td>Unknown</td>
            <td>13-12-2016 06:08 PM</td>
          </tr>
          <tr>
            <td>21</td>
            <td>Product Sale</td>
            <td>57.00</td>
            <td>341.59</td>
            <td></td>
            <td>Me</td>
            <td>13-12-2016 06:08 PM</td>
          </tr>
          <tr>
            <td>22</td>
            <td>Users Withdraw</td>
            <td>14.00</td>
            <td>341.59</td>
            <td></td>
            <td>Me</td>
            <td>13-12-2016 06:00 PM</td>
          </tr>
          <tr>
            <td>23</td>
            <td>Users Withdraw</td>
            <td>91.00</td>
            <td>327.59</td>
            <td></td>
            <td>Me</td>
            <td>13-12-2016 01:06 PM</td>
          </tr>
          <tr>
            <td>24</td>
            <td>Users Withdraw</td>
            <td>52.50</td>
            <td>236.59</td>
            <td></td>
            <td>Me</td>
            <td>10-12-2016 05:35 PM</td>
          </tr>
          <tr>
            <td>25</td>
            <td>Product Sale</td>
            <td>57.00</td>
            <td>184.09</td>
            <td></td>
            <td>Me</td>
            <td>05-12-2016 06:53 PM</td>
          </tr>
          <tr>
            <td>26</td>
            <td>Users Product Balance</td>
            <td>57.00</td>
            <td>241.09</td>
            <td></td>
            <td>Unknown</td>
            <td>05-12-2016 06:53 PM</td>
          </tr>
          <tr>
            <td>27</td>
            <td>Product Sale</td>
            <td>485.00</td>
            <td>184.09</td>
            <td></td>
            <td>Me</td>
            <td>05-12-2016 03:57 PM</td>
          </tr>
          <tr>
            <td>28</td>
            <td>Users Withdraw</td>
            <td>91.88</td>
            <td>669.09</td>
            <td></td>
            <td>Me</td>
            <td>04-12-2016 06:40 PM</td>
          </tr>
          <tr>
            <td>29</td>
            <td>Product Sale</td>
            <td>435.00</td>
            <td>577.21</td>
            <td></td>
            <td>Me</td>
            <td>04-12-2016 01:28 PM</td>
          </tr>
          <tr>
            <td>30</td>
            <td>Product Sale</td>
            <td>95.00</td>
            <td>1,012.21</td>
            <td></td>
            <td>Me</td>
            <td>28-11-2016 12:08 PM</td>
          </tr>
          <tr>
            <td>31</td>
            <td>Users Product Balance</td>
            <td>95.00</td>
            <td>1,107.21</td>
            <td></td>
            <td>Unknown</td>
            <td>28-11-2016 12:08 PM</td>
          </tr>
          <tr>
            <td>32</td>
            <td>Received from Admin</td>
            <td>1,000.00</td>
            <td>1,012.21</td>
            <td>sl-6250</td>
            <td>AIL-2</td>
            <td>24-11-2016 05:33 PM</td>
          </tr>
          <tr>
            <td>33</td>
            <td>Product Sale</td>
            <td>420.00</td>
            <td>12.21</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 02:51 PM</td>
          </tr>
          <tr>
            <td>34</td>
            <td>Product Sale</td>
            <td>420.00</td>
            <td>432.21</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 02:42 PM</td>
          </tr>
          <tr>
            <td>35</td>
            <td>Users Withdraw</td>
            <td>52.50</td>
            <td>852.21</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 02:14 PM</td>
          </tr>
          <tr>
            <td>36</td>
            <td>Users Withdraw</td>
            <td>46.90</td>
            <td>799.71</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 02:14 PM</td>
          </tr>
          <tr>
            <td>37</td>
            <td>Users Withdraw</td>
            <td>367.50</td>
            <td>752.81</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 01:57 PM</td>
          </tr>
          <tr>
            <td>38</td>
            <td>Product Sale</td>
            <td>160.00</td>
            <td>385.31</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 01:07 PM</td>
          </tr>
          <tr>
            <td>39</td>
            <td>Users Product Balance</td>
            <td>160.00</td>
            <td>545.31</td>
            <td></td>
            <td>Unknown</td>
            <td>22-11-2016 01:07 PM</td>
          </tr>
          <tr>
            <td>40</td>
            <td>Product Sale</td>
            <td>167.00</td>
            <td>385.31</td>
            <td></td>
            <td>Me</td>
            <td>22-11-2016 12:48 PM</td>
          </tr>
          <tr>
            <td>41</td>
            <td>Users Product Balance</td>
            <td>167.00</td>
            <td>552.31</td>
            <td></td>
            <td>Unknown</td>
            <td>22-11-2016 12:48 PM</td>
          </tr>
          <tr>
            <td>42</td>
            <td>Users Withdraw</td>
            <td>35.00</td>
            <td>385.31</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 06:10 PM</td>
          </tr>
          <tr>
            <td>43</td>
            <td>Users Withdraw</td>
            <td>22.05</td>
            <td>350.31</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 06:07 PM</td>
          </tr>
          <tr>
            <td>44</td>
            <td>Product Sale</td>
            <td>435.00</td>
            <td>328.26</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 05:49 PM</td>
          </tr>
          <tr>
            <td>45</td>
            <td>Product Sale</td>
            <td>435.00</td>
            <td>763.26</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 05:36 PM</td>
          </tr>
          <tr>
            <td>46</td>
            <td>Product Sale</td>
            <td>435.00</td>
            <td>1,198.26</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 05:22 PM</td>
          </tr>
          <tr>
            <td>47</td>
            <td>Received from Admin</td>
            <td>1,000.00</td>
            <td>1,633.26</td>
            <td>sl-6158</td>
            <td>AIL-2</td>
            <td>21-11-2016 03:55 PM</td>
          </tr>
          <tr>
            <td>48</td>
            <td>Users Withdraw</td>
            <td>441.88</td>
            <td>633.26</td>
            <td></td>
            <td>Me</td>
            <td>21-11-2016 12:09 PM</td>
          </tr>
          <tr>
            <td>49</td>
            <td>Users Withdraw</td>
            <td>26.25</td>
            <td>191.38</td>
            <td></td>
            <td>Me</td>
            <td>17-11-2016 07:53 PM</td>
          </tr>
          <tr>
            <td>50</td>
            <td>Product Sale</td>
            <td>435.00</td>
            <td>165.13</td>
            <td></td>
            <td>Me</td>
            <td>17-11-2016 02:40 PM</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
