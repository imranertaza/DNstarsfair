<?php print $sidebar_left; ?>

<div class="col-md-9">
  <div class="right_contant dashboard_right">
    <div class="top_right_content">
      <h1>Balance Request Log</h1>
      <hr />
      <table class="table-bordered table-hover table">
        <tbody>
          <tr>
            <th>#</th>
            <th>Request Date</th>
            <th width="68%">Remarks</th>
            <th>Amount</th>
          </tr>
          <tr>
            <td>1</td>
            <td>06-09-2016 14:00</td>
            <td>uzzal</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>2</td>
            <td>09-09-2016 17:24</td>
            <td>uzzal</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>3</td>
            <td>19-09-2016 12:49</td>
            <td>uzzal</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>4</td>
            <td>21-09-2016 16:47</td>
            <td>five thousand</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>5</td>
            <td>26-09-2016 11:27</td>
            <td>five thousand</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>6</td>
            <td>27-09-2016 14:51</td>
            <td>three thousand</td>
            <td>3000</td>
          </tr>
          <tr>
            <td>7</td>
            <td>28-09-2016 11:25</td>
            <td>three thousand</td>
            <td>3000</td>
          </tr>
          <tr>
            <td>8</td>
            <td>01-10-2016 16:53</td>
            <td>five thousand</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>9</td>
            <td>06-10-2016 14:10</td>
            <td>two thousand taka</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>10</td>
            <td>08-10-2016 11:30</td>
            <td>three thousand only</td>
            <td>3000</td>
          </tr>
          <tr>
            <td>11</td>
            <td>09-10-2016 13:39</td>
            <td>two thousand only</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>12</td>
            <td>10-10-2016 17:30</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>13</td>
            <td>15-10-2016 16:48</td>
            <td>two thousand only</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>14</td>
            <td>16-10-2016 15:18</td>
            <td>two thousand only</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>15</td>
            <td>17-10-2016 12:47</td>
            <td>two thousand only</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>16</td>
            <td>17-10-2016 16:52</td>
            <td>two thousand only</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>17</td>
            <td>18-10-2016 13:02</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>18</td>
            <td>19-10-2016 12:46</td>
            <td>five thousand</td>
            <td>5000</td>
          </tr>
          <tr>
            <td>19</td>
            <td>20-10-2016 13:02</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>20</td>
            <td>24-10-2016 14:20</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>21</td>
            <td>27-10-2016 13:46</td>
            <td>ten thousand only</td>
            <td>100000</td>
          </tr>
          <tr>
            <td>22</td>
            <td>30-10-2016 17:02</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>23</td>
            <td>02-11-2016 15:45</td>
            <td>two thousand</td>
            <td>2000</td>
          </tr>
          <tr>
            <td>24</td>
            <td>09-11-2016 10:40</td>
            <td>one thousand</td>
            <td>1000</td>
          </tr>
          <tr>
            <td>25</td>
            <td>14-11-2016 16:22</td>
            <td>one thousand</td>
            <td>1000</td>
          </tr>
          <tr>
            <td>26</td>
            <td>17-11-2016 13:24</td>
            <td>onthousand</td>
            <td>1000</td>
          </tr>
          <tr>
            <td>27</td>
            <td>21-11-2016 15:52</td>
            <td>Uzzal</td>
            <td>1000</td>
          </tr>
          <tr>
            <td>28</td>
            <td>24-11-2016 15:37</td>
            <td>one thousand</td>
            <td>1000</td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</div>
