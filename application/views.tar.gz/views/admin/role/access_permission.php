<div id="page-wrapper">
            
            
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Permissions List</h1>
                </div>
            </div>
                    
            <div class="panel panel-default">
                <div class="panel-body">
                    <div class="col-lg-12">
                            <div class="col-lg-3"><?php $this->functions->permission_list(); ?></div>
                    </div>
                </div>
            </div>
            
        </div>