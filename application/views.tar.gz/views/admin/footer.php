</div>
    <!-- /#wrapper -->

    <!-- Custom Theme JavaScript -->
    <script src="<?php echo base_url(); ?>assets/js/sb-admin-2.js"></script>
    
<script>
CKEDITOR.replace( 'ckeditor', { 
	filebrowserBrowseUrl: '<?php print base_url(); ?>assets/ckeditor/plugins/w3bdeveloper_uimages/index.php',
	filebrowserWindowWidth: '860',
	filebrowserWindowHeight: '660'
});
</script>

</body>

</html>
