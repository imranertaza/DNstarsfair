<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class member_form extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->library('session');
		$this->load->helper('url');
		$this->load->helper('settings_functions_helper');
		$this->load->database();
		$this->load->model('functions');
		$this->load->library('form_validation');
		$this->load->model('users/user_login');
		if ($this->session->userdata('m_logged_in') == true) {
			$this->m_logged_in = true;
		}else {
			$this->m_logged_in = false;
		}
		
		$this->load->helper('settings_functions_helper');
		$this->load->helper('path');
		$this->load->library('pagination');
		$this->load->model('settings/global_settings');
		$this->load->model('functions');
		
	}
	
	public function index()
	{

		$data['dwn_path'] = base_url()."uploads/downloads/"; //$get_download;
		
		
		$notice_list = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC LIMIT 0, 5");
		if ($notice_list->num_rows() > 0)
		{
		   $data['list_notice'] = $notice_list->result();
		}else {
			$data['list_notice'] = 'No notice published';	
		}

		$data['footer_widget_title'] = $this->functions->show_widget('title', 8);
		$data['footer_widget_description'] = $this->functions->show_widget('description', 8);
		
		$data['footer_widget2_title'] = $this->functions->show_widget('title', 9);
		$data['footer_widget2_description'] = $this->functions->show_widget('description', 9);
		
		$data['page_title'] = 'home';
		$data['slider'] = '';
		
		if ($this->m_logged_in == true) {
			$data['log_url'] = 'member_form/logout_member.html';
			$data['log_title'] = 'Logout';
			$data['check_user'] = $this->session->userdata('m_logged_in');
			$data['ID'] = $this->session->userdata('user_id');
			$data['u_name'] = get_field_by_id_from_table('users', 'username', 'ID', $data['ID']);
			$data['f_name'] = get_field_by_id_from_table('users', 'f_name', 'ID', $data['ID']);
			$data['l_name'] = get_field_by_id_from_table('users', 'l_name', 'ID', $data['ID']);
			$data['balance'] = get_field_by_id_from_table('users', 'balance', 'ID', $data['ID']);
			$data['point'] = get_field_by_id_from_table('users', 'point', 'ID', $data['ID']);
			$data['role'] = get_field_by_id_from_table('user_roles', 'roleID', 'userID', $data['ID']);
			$data['sidebar_left'] = $this->load->view('front/client_area/sidebar-left', $data, true);
			$this->load->view('front/client_area/header', $data);
			$this->load->view('front/client_area/member_form', $data);
			$this->load->view('front/client_area/footer', $data);
		}else{
			$data['check_user'] = '';
			$data['log_url'] = 'member_form/login.html';
			$data['log_title'] = 'Login';
			$data['sidebar_left'] = $this->load->view('front/sidebar-left', $data, true);
			$this->load->view('front/header', $data);
			$this->load->view('front/member_form', $data);
			$this->load->view('front/footer', $data);
		}
		
	}
	
	
	
	/*public function my_tree($user_id=0)
	{
		$this->load->helper('student_functions_helper');
		
		$data['dwn_path'] = base_url()."uploads/downloads/";
		$notice_list = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC LIMIT 0, 5");
		if ($notice_list->num_rows() > 0)
		{
		   $data['list_notice'] = $notice_list->result();
		}else {
			$data['list_notice'] = 'No notice published';	
		}

		$data['footer_widget_title'] = $this->functions->show_widget('title', 8);
		$data['footer_widget_description'] = $this->functions->show_widget('description', 8);
		
		$data['footer_widget2_title'] = $this->functions->show_widget('title', 9);
		$data['footer_widget2_description'] = $this->functions->show_widget('description', 9);
		
		$data['page_title'] = 'home';
		$data['slider'] = '';
		
		if ($this->m_logged_in == true) {
			$data['log_url'] = 'member_form/logout_member.html';
			$data['log_title'] = 'Logout';
			$data['check_user'] = $this->session->userdata('m_logged_in');
			$data['ID'] = $this->session->userdata('user_id');
			$data['u_name'] = get_field_by_id_from_table('users', 'username', 'ID', $data['ID']);
			$data['f_name'] = get_field_by_id_from_table('users', 'f_name', 'ID', $data['ID']);
			$data['l_name'] = get_field_by_id_from_table('users', 'l_name', 'ID', $data['ID']);
			$data['balance'] = get_field_by_id_from_table('users', 'balance', 'ID', $data['ID']);
			$data['point'] = get_field_by_id_from_table('users', 'point', 'ID', $data['ID']);
			$data['role'] = get_field_by_id_from_table('user_roles', 'roleID', 'userID', $data['ID']);
			$data['user_id'] = $user_id;
			$data['sidebar_left'] = $this->load->view('front/client_area/sidebar-left', $data, true);
			$this->load->view('front/client_area/header', $data);
			$this->load->view('front/my_tree', $data);
			$this->load->view('front/client_area/footer', $data);
		}else{
			$data['check_user'] = '';
			$data['log_url'] = 'member_form/login.html';
			$data['log_title'] = 'Login';
			$data['sidebar_left'] = $this->load->view('front/sidebar-left', $data, true);
			$this->load->view('front/header', $data);
			$this->load->view('front/member_form', $data);
			$this->load->view('front/footer', $data);
		}
		
	}*/
	



	public function login() {

		$home_page_query = $this->db->query("SELECT * FROM `pages` where `page_id` = '100'");
		$h_page_query = $home_page_query->row();
		$data['title'] = $h_page_query->page_title;
		$data['description'] = $h_page_query->page_description;
		$data['check_user'] = $this->session->userdata('m_logged_in');
		$data['slider'] = '';
		$login = '';
		

		$latest_notice = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC");
		$last_notice = $latest_notice->row();
		$data['notice_title'] = $last_notice->title;
		$data['notice_description'] = $last_notice->description;
		$data['notice_file'] = $last_notice->file;
		
		
		$data['dwn_path'] = base_url()."uploads/downloads/"; //$get_download;
		
		
		$notice_list = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC LIMIT 0, 5");
		if ($notice_list->num_rows() > 0)
		{
		   $data['list_notice'] = $notice_list->result();
		}else {
			$data['list_notice'] = 'No notice published';	
		}
		
		$data['footer_widget_title'] = $this->functions->show_widget('title', 8);
		$data['footer_widget_description'] = $this->functions->show_widget('description', 8);
		
		$data['footer_widget2_title'] = $this->functions->show_widget('title', 9);
		$data['footer_widget2_description'] = $this->functions->show_widget('description', 9);
		

		if (isset($_POST['login'])) {
		$this->form_validation->set_rules('username', 'Usernmae', 'trim|required|min_length[5]|xss_clean');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[10]|xss_clean');
			
			if ($this->form_validation->run() == TRUE) {
				$login = $this->user_login->login_member();
			}
		}
		
		if (($this->m_logged_in == true) || ($login)) {
		    redirect("member/dashboard/");
//			$data['check_user'] = $this->session->userdata('m_logged_in');
//			$data['ID'] = $this->session->userdata('user_id');
//			$data['u_name'] = get_field_by_id_from_table('users', 'username', 'ID', $data['ID']);
//			$data['f_name'] = get_field_by_id_from_table('users', 'f_name', 'ID', $data['ID']);
//			$data['l_name'] = get_field_by_id_from_table('users', 'l_name', 'ID', $data['ID']);
//			$data['balance'] = get_field_by_id_from_table('users', 'balance', 'ID', $data['ID']);
//			$data['point'] = get_field_by_id_from_table('users', 'point', 'ID', $data['ID']);
//			$data['role'] = get_field_by_id_from_table('user_roles', 'roleID', 'userID', $data['ID']);
//			$data['page_title'] = 'home';
//			$data['log_url'] = 'member_form/logout_member.html';
//			$data['log_title'] = 'Logout';
//			$data['sidebar_left'] = $this->load->view('front/client_area/sidebar-left', $data, true);
//			$this->load->view('front/client_area/header', $data);
//			$this->load->view('front/client_area/member_form', $data);
//			$this->load->view('front/client_area/footer', $data);
		}else {
			$data['log_url'] = 'member_form/login.html';
			$data['log_title'] = 'Login';
			$data['sidebar_left'] = $this->load->view('front/sidebar-left', $data, true);
			$this->load->view('front/header', $data);
			$this->load->view('front/member_form', $data);
			$this->load->view('front/footer', $data);	
		}	
		
	}
	
	
	
	
	
	public function register() {
		
		$this->load->helper('student_functions_helper');
		
		$data['dwn_path'] = base_url()."uploads/downloads/"; //$get_download;
		$notice_list = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC LIMIT 0, 5");
		if ($notice_list->num_rows() > 0)
		{
		   $data['list_notice'] = $notice_list->result();
		}else {
			$data['list_notice'] = 'No notice published';	
		}

		$data['footer_widget_title'] = $this->functions->show_widget('title', 8);
		$data['footer_widget_description'] = $this->functions->show_widget('description', 8);
		
		$data['footer_widget2_title'] = $this->functions->show_widget('title', 9);
		$data['footer_widget2_description'] = $this->functions->show_widget('description', 9);
		
		$data['page_title'] = 'home';
		$data['slider'] = '';
		
		
		
		
		if ($this->m_logged_in == true) {
		    redirect("member/dashboard/");
//			$data['log_url'] = 'member_form/logout_member.html';
//			$data['log_title'] = 'Logout';
//			$data['check_user'] = $this->session->userdata('m_logged_in');
//			$data['ID'] = $this->session->userdata('user_id');
//			$data['u_name'] = get_field_by_id_from_table('users', 'username', 'ID', $data['ID']);
//			$data['f_name'] = get_field_by_id_from_table('users', 'f_name', 'ID', $data['ID']);
//			$data['l_name'] = get_field_by_id_from_table('users', 'l_name', 'ID', $data['ID']);
//			$data['balance'] = get_field_by_id_from_table('users', 'balance', 'ID', $data['ID']);
//			$data['point'] = get_field_by_id_from_table('users', 'point', 'ID', $data['ID']);
//			$data['role'] = get_field_by_id_from_table('user_roles', 'roleID', 'userID', $data['ID']);
//			$data['sidebar_left'] = $this->load->view('front/client_area/sidebar-left', $data, true);
//			$this->load->view('front/client_area/header', $data);
//			$this->load->view('front/register', $data);
//			$this->load->view('front/client_area/footer', $data);
		}else{
			$data['check_user'] = '';
			$data['log_url'] = 'member_form/login.html';
			$data['log_title'] = 'Login';
			$data['sidebar_left'] = $this->load->view('front/sidebar-left', $data, true);
			$this->load->view('front/header', $data);
			$this->load->view('front/register', $data);
			$this->load->view('front/footer', $data);
		}
		
		
	}



	function register_action(){


        if (isset($_POST['add_user'])) {
            $this->rules();

            if ($this->form_validation->run() == TRUE) {


                //Image upload into temp file
                $photo_name = 'profile_' . time() . '.jpg';
                $config['upload_path'] = 'uploads/temp/';
                $config['allowed_types'] = 'gif|jpg|png';
                $config['file_name'] = $photo_name;
                $config['max_size'] = '100';
                $config['image_width'] = '1024';
                $config['image_height'] = '768';
                $config['is_image'] = 1;
                $config['max_size'] = 0;
                $this->session->set_userdata("config", $config);
                $this->load->library('upload', $config);
                $this->upload->do_upload('photo');


                // Insert into user
                $data_personal = array(
                    'email' => $_POST['email'],
                    'username' => $_POST['uname'],
                    'password' => md5($_POST['pass']),
                    'f_name' => $_POST['fname'],
                    'l_name' => "no_need",
                    'address1' => "no_need",
                    'phn_no' => $_POST['phone'],
                    'balance' => '0',
                    'point' => '0',
                    'status' => 'Inactive',
                    'address2' => "no_need",
                    'religion' => "no_need",
                    'sex' => "no_need",
                    'photo' => "no_need.jpg"
                );
                $this->db->insert('users', $data_personal);
                $userID = $this->db->insert_id();


                // Insert into user_role
                $current_time = date('Y-M-D h:m:s');
                $data_role = array(
                    'userID' => $userID,
                    'roleID' => 6,
                    'addDate' => $current_time
                );
                $this->db->insert('user_roles', $data_role);


                // Insert into tree
                $pid = get_ID_by_username($_POST['p_id']);
                //$ref_id = get_ID_by_username($_POST['ref_id']);
                $spon_id = get_ID_by_username($_POST['spon_id']);
                $data_tree = array(
                    'u_id' => $userID,
                    'pr_id' => $pid,
                    'ref_id' => "no_need",
                    'agent_id' => $this->session->userdata('user_id'),
                    'spon_id' => $spon_id
                );
                $this->db->insert('tree', $data_tree);

                // Update tree for left and right
                if ($_POST['position'] == 1) {
                    $data_left_right = array(
                        'l_t' => $userID
                    );
                }
                if ($_POST['position'] == 2) {
                    $data_left_right = array(
                        'r_t' => $userID
                    );
                }
                $this->db->where('u_id', $pid);
                $this->db->update('tree', $data_left_right);


                //Sponsor commision will be added to main Commission
                $previous_bal = get_field_by_id_from_table("users", "commission", "ID", $spon_id);
                $sponsor_com = get_field_by_id_from_table("global_settings", "value", "title", "sponsor_commission");
                $sponsor_commision = array(
                    'commission' => $previous_bal + $sponsor_com,
                );
                $this->db->where('ID', $spon_id);
                $this->db->update('users', $sponsor_commision);


                // Sponsor commission Statement
                $spon_commision_statement = array(
                    'u_id' => $spon_id,
                    'purpose' => "Sponsor commission of a register new member",
                    'amount' => $sponsor_com,
                );
                $this->db->insert('comm_spot', $spon_commision_statement);


                //All Users Perent_point will be increased And matching
                $min_matching_point = get_field_by_id_from_table("global_settings", "value", "title", "min_matching_point");
                $per_day_matching = get_field_by_id_from_table("global_settings", "value", "title", "per_day_matching");
                $matching_commission = get_field_by_id_from_table("global_settings", "value", "title", "matching_commission");

                $parent_id = get_field_by_id_from_table("tree", "pr_id", "u_id", $userID);
                $user_id = $userID;
                while (!empty($parent_id)) {


                    //Increasing Parent hand point (left or right)
                    $this->db->select('l_t, r_t');
                    $this->db->from('tree');
                    $this->db->where("u_id", $parent_id);
                    $hand = $this->db->get()->row();
                    if ($hand->l_t == $user_id) {
                        $point_hand = "lpoint";
                    }
                    if ($hand->r_t == $user_id) {
                        $point_hand = "rpoint";
                    }
                    $old_point = get_field_by_id_from_table("users", $point_hand, "ID", $parent_id);
                    $pr_point = array(
                        $point_hand => $old_point + $min_matching_point
                    );
                    $this->db->where('ID', $parent_id);
                    $this->db->update('users', $pr_point);


                    //Matching Commission
                    $com_taken_on_day = $this->db->query("SELECT * FROM `comm_matching` WHERE `u_id` = $parent_id AND `date` BETWEEN '" . date("Y-m-d") . " 00:00:00' AND '" . date("Y-m-d") . " 23:59:59'")->num_rows();
                    if ($com_taken_on_day < $per_day_matching) {


                        $lpoint = get_field_by_id_from_table("users", "lpoint", "ID", $parent_id);
                        $rpoint = get_field_by_id_from_table("users", "rpoint", "ID", $parent_id);


                        if (($lpoint >= $min_matching_point) && ($rpoint >= $min_matching_point) && !empty($hand->l_t) && !empty($hand->r_t)) {

                            $existing_com = get_field_by_id_from_table("users", "commission", "ID", $parent_id);
                            if ($lpoint > $rpoint) {
                                $next_com_times = floor($lpoint / $min_matching_point);
                            } else {
                                $next_com_times = floor($rpoint / $min_matching_point);
                            }
                            $matching_com = $next_com_times * $matching_commission;
                            $next_com = $existing_com + $matching_com;


                            // Updating commission on user table
                            $data = array(
                                'commission' => $next_com
                            );
                            $this->db->where('ID', $parent_id);
                            $this->db->update('users', $data);


                            //Inserting into matching commission table
                            for ($i = 1; $i <= $next_com_times; $i++) {
                                $data = array(
                                    'u_id' => $parent_id,
                                    'purpose' => 'Matching Commission',
                                    'amount' => $matching_commission
                                );
                                $this->db->insert('comm_matching', $data);
                            }


                            //Decreasing Left point
                            $matching_point = $next_com_times * $min_matching_point;
                            $left_data = array(
                                'lpoint' => $lpoint - $matching_point,
                                'rpoint' => $rpoint - $matching_point
                            );
                            $this->db->where('ID', $parent_id);
                            $this->db->update('users', $left_data);


                            // Flash existing point after 25
                            if ($com_taken_on_day == $per_day_matching) {
                                if ($lpoint > $rpoint) {
                                    $flash_hand = "rpoint";
                                } else {
                                    $flash_hand = "lpoint";
                                }
                                $flashdata = array(
                                    $flash_hand => 0
                                );
                                $this->db->where('ID', $parent_id);
                                $this->db->update('users', $flashdata);
                            }

                        }

                    }
                    $user_id = $parent_id;
                    $parent_id = get_field_by_id_from_table("tree", "pr_id", "u_id", $parent_id);
                }


                $this->session->set_flashdata("msg", "<div class='alert alert-success'>Successfully Registered. Please Login</div>");
                redirect("member/dashboard/");
            }else{
                $this->session->set_flashdata("msg", validation_errors('<div class="alert alert-warning">', '</div>'));
                redirect("member_form/register/");
            }
        }else{
            redirect("member_form/register/");
        }


    }
	
	
    private function rules() {
        $this->form_validation->set_rules('fname', 'First Name', 'required|xss_clean|encode_php_tags');
        $this->form_validation->set_rules('phone', 'Phone', 'xss_clean|encode_php_tags|is_natural');
        $this->form_validation->set_rules('spon_id', 'Sponsor ID', 'required|xss_clean|encode_php_tags');
        $this->form_validation->set_rules('p_id', 'Placement ID', 'required|xss_clean|encode_php_tags');
        $this->form_validation->set_rules('position', 'Side', 'required|xss_clean|encode_php_tags|integer|min_length[1]|max_length[1]');
        $this->form_validation->set_rules('uname', 'Username', 'required|min_length[5]|max_length[20]|is_unique[users.username]');
        $this->form_validation->set_rules('pass', 'Password', 'required|matches[con_pass]|min_length[10]|max_length[20]');
        $this->form_validation->set_rules('con_pass', 'Password Confirmation', 'required||min_length[10]|max_length[20]');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
    }

	function logout_member() {
		$home_page_query = $this->db->query("SELECT * FROM `pages` where `page_id` = '100'");
		$h_page_query = $home_page_query->row();
		$data['title'] = $h_page_query->page_title;
		$data['description'] = $h_page_query->page_description;
		$data['check_user'] = false;
		$data['slider'] = '';
		
		$notice_list = $this->db->query("SELECT * FROM `downloads` WHERE `cat_id` IN (5) ORDER BY `dwn_id` DESC LIMIT 0, 5");
		if ($notice_list->num_rows() > 0)
		{
		   $data['list_notice'] = $notice_list->result();
		}else {
			$data['list_notice'] = 'No notice published';	
		}
		
		$data['page_title'] = 'home';
		$data['sidebar_left'] = $this->load->view('front/sidebar-left', $data, true);
		
		$data['footer_widget_title'] = $this->functions->show_widget('title', 8);
		$data['footer_widget_description'] = $this->functions->show_widget('description', 8);
		
		$data['footer_widget2_title'] = $this->functions->show_widget('title', 9);
		$data['footer_widget2_description'] = $this->functions->show_widget('description', 9);
		
		$data['log_url'] = 'member_form/login.html';
		$data['log_title'] = 'Login';
		
		
		$this->session->unset_userdata('m_logged_in');
		$this->session->sess_destroy();
		$this->load->view('front/header', $data);
		$this->load->view('front/member_form', $data);
		$this->load->view('front/footer', $data);
	}
	
}
